

<?php $__env->startSection('content'); ?>

<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Product</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">View multiple image</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    Product: <?php echo e($selectedproduct->product_name); ?> 
                    <a href="<?php echo e(route('product.view_unsold')); ?>"  style="float: right;">View Unsold Product</a>
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <strong>Success!</strong> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" style="float:right;">&times;</button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="row">
                                                                        
                        <div class="col-md-3">
                                <div class="p-20">
                                    <h5>Thumbnail Image </h5>
                                    <img src="<?php echo e(asset($selectedproduct->thumbnail_image)); ?>" style="height:200px;widht:180px;">

                                    <a href="<?php echo e(url('productthumbnailimage/edit/'.$selectedproduct->id)); ?>" class="btn btn-success" style="float:left;">Edit</a>
                                        
                                </div>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            
                            <a href="<?php echo e(url('productimage/delete_all_productimage/'.$selectedproduct->id)); ?>" onclick="return confirm('Are you shure want to delete all multiple image')" class="btn btn-danger" style="float: right;">Delete All Multiple Image</a>
                            <a href="<?php echo e(url('productimage/addmore/'.$selectedproduct->id)); ?>" class="btn btn-primary" style="float: right;">Add More Multiple Image</a>
                            
                        </div>
                    </div>    

                    <div class="row">
                   
                    <?php $__currentLoopData = $productmultipleimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="p-20">
                                <a href="<?php echo e(url('productimage/edit/'.$pimage->id.'/'.$selectedproduct->id)); ?>" class="btn btn-success" style="float:left;">Edit</a>
                                <img src="<?php echo e(asset($pimage->image_ms)); ?>" style="float:left;height:auto;widht:200px;">
                                <a href="<?php echo e(url('productimage/delete/'.$pimage->id)); ?>" onclick="return confirm('Are you Shure want to delete?')" class="btn btn-danger" style="float:left;">Delete</a>

                            </div>
                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>



                </div>
            </div>

        </div>
    </div>
</div>


<script>
    var loadFile = function(event) {
      var output = document.getElementById('output');
      output.src = URL.createObjectURL(event.target.files[0]);
      output.onload = function() {
        URL.revokeObjectURL(output.src) // free memory
      }
    };
  </script>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/backend/admin/product_multiple_image/view_multiple_image.blade.php ENDPATH**/ ?>