<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 <section class="section swiper-slider_style-1">
  <div class="swiper-container swiper-slider swiper-slider_height-1" data-loop="true" data-autoplay="false" data-simulate-touch="false" data-additional-slides="0" data-custom-prev="#swiper-prev" data-custom-next="#swiper-next" data-custom-slide-effect="interLeaveEffect">
    <div class="swiper-wrapper">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
      <div class="swiper-slide context-light">
        <div class="slide-inner" style="background-image: url(<?php echo e($slider->slider_image); ?>);">
          <div class="swiper-slide-caption">
            <div class="shell">
            <?php  
              if(session()->get('language')=='en')
              {
            ?>
              <h1 data-caption-animate="fadeInUpSmall" style="color: #fff;"><?php echo e($slider->title); ?></h1>
              <div class="object-decorated"><span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550" style="color: #fff;"><?php echo e($slider->subtitle); ?></h4>
             <?php 
              }
              else {
              ?>
              <h1 data-caption-animate="fadeInUpSmall" style="color: #fff;"><?php echo e($slider->title_jp); ?></h1>
              <div class="object-decorated"><span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550" style="color: #fff;"><?php echo e($slider->subtitle_jp); ?></h4>
              <?php   
              }
             ?>   
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     

      

    </div>
    <div class="swiper-pagination"></div>
  </div>
  <div class="swiper-navigation swiper-navigation_modern">
    <div class="swiper-button-prev" id="swiper-prev"></div>
    <div class="swiper-button-next" id="swiper-next"></div>
  </div>
</section>

<!--============================= Category View ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall" data-wow-offset="150">
    
      <?php 
      if(count($categories)>0) 
      { 
      ?>
      <div class="shell-fullwidth">
        <h2 style="text-align: center;">製品カテゴリー</h2>
      </div>
      <?php 
      }
      ?>
    
    <!-- Owl Carousel-->
    <div class="owl-carousel owl-carousel_style-2" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-dots="true" data-nav="false" data-stage-padding="15" data-loop="true" data-margin="30" data-mouse-drag="false">
      
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item">
        <a class="thumb-corporate" href="<?php echo e(route('fabrication',[$cat->id])); ?>">
          <div class="thumb-corporate__inner"><img src="<?php echo e(asset($cat->image)); ?>" alt="" width="370" height="303"/>
          </div>
          <p class="thumb-corporate__title"><?php echo e($cat->title_jp); ?></p>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
  </div>
</section>


<!--====================== Our Projects ========================================-->
<section class="section section-md bg-white text-center">
  <div class="shell-fullwidth">
    <h2>製品事例</h2>
    <!-- Owl Carousel-->
    <div class="owl-carousel owl-carousel_style-2 wow fadeIn" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-dots="true" data-nav="true" data-loop="true" data-stage-padding="0" data-sm-stage-padding="20" data-md-stage-padding="0" data-sm-margin="15" data-lg-margin="0" data-mouse-drag="false">
      <?php $__currentLoopData = $our_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="thumb-janez">
        <figure class="thumb-janez__image-wrap">
          <img src="<?php echo e(asset($p->thumbnail_image)); ?>" alt="" width="481" height="383"/>
        </figure>
        <div class="thumb-janez__content bg-gray-dark">
          <div class="thumb-janez__content-inner">
            <h5><a href="#"><?php echo e($p->title_jp); ?></a></h5>
            <p><?php echo e($p->short_des); ?></p>
            <a class="button button-xs button-darker" href="<?php echo e(route('fabrications')); ?>">続きを読みます</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

    </div>
  </div>
</section>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/jp/welcome.blade.php ENDPATH**/ ?>