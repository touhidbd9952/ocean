

<?php $__env->startSection('content'); ?>

 <style>
  form label{text-align: right;}
 </style>

<?php 
$base_url = Session::get('base_url');
?>
<script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>

  <!-- Get in Touch-->
  <section class="section section-lg bg-white">
    <div class="shell">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-md-12" style="text-align: center;">
            <span style="float: right;color: #9f9797;">
                <?php 
                $logger_seeker_title = Session::get('logger_seeker_title') ;
                echo 'Job Seeker: '.$logger_seeker_title;
                ?>
            </span>
            <br>
            <h3  style="font-size: 20px;text-align: left;color:black;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
              Work Type: Normal
            </h3>

          <div style="padding: 5px;">
            <div class="table-responsive" style="background: #fff;">
                <table id="zero_config" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                          <th style="width: 10%;">SL</th>
                          <th style="width: 60%;">Work</th>
                          <th style="width: 30%;">Charge (per hour)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sl=1;
                        ?>
                    <?php $__currentLoopData = $workinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    if($b->work_type_id == 2)
                    {
                    ?>    

                        <tr>
                            <td><?php echo $sl++;?></td>
                            <td><?php echo e($b->work_title); ?></td>
                            <td><?php echo e($b->charge); ?>&nbsp;¥</td>
                            
                        </tr>
                    <?php 
                    }
                    ?>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                    
                </table>

            </div>
          </div>


          <!---===================--->
          
          <h3  style="font-size: 20px;text-align: left;color:black;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
            Work Type: Heavy
          </h3>

        <div style="padding: 5px; margin-bottom: 30px;">
          <div class="table-responsive" style="background: #fff;">
              <table id="zero_config" class="table table-striped table-bordered">
                  <thead>
                      <tr>
                          <th style="width: 10%;">SL</th>
                          <th style="width: 60%;">Work</th>
                          <th style="width: 30%;">Charge (per hour)</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php 
                      $sl=1;
                      ?>
                  <?php $__currentLoopData = $workinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                  if($b->work_type_id == 1)
                  {
                  ?>    

                      <tr>
                          <td><?php echo $sl++;?></td>
                          <td><?php echo e($b->work_title); ?></td>
                          <td><?php echo e($b->charge); ?>&nbsp;¥</td>
                          
                      </tr>
                  <?php 
                  }
                  ?>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                  </tbody>
                  
              </table>

          </div>
        </div>

            
          </div>
      </div>

     </div>
    </div>
  </section>








  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freeman\resources\views/fontend/en/job_and_payments_detais.blade.php ENDPATH**/ ?>