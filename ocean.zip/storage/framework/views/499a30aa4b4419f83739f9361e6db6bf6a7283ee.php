<html>
  <head>

    <meta http-equiv="content-type" content="text/html; ">
  </head>
  <body>
    <br>
      <br>
      <br>
      <?php echo e($auctiondata['companyname']); ?><br>    
      <?php echo e($auctiondata['person_incharge']); ?> 様 入札者番号：<?php echo e($auctiondata['biddercode']); ?><br>
      <br>
      Woodyオークションに参加いただきありがとうございます。<br>
      お客様の入札された内容は下記のとおりです。ご確認下さい。<br>
      <br>
      /_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/<br>
      <br>
      【オークション No】: <?php echo e($auctiondata['auctionno']); ?><br>
      【モデル】 : <?php echo e($auctiondata['modelno']); ?><br>
      【入札金額】　: <?php echo e($auctiondata['bid_max_price']); ?> <br>
      [受渡場所] <?php echo e($auctiondata['deliveryplace']); ?><br>
      /_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/<br>
      <br><br>
      本日は　Woodyオークションに参加いただきありがとうございます。<br><br>

      *請求書は明日ＦＡＸにて送信させていただきます。<br><br><br>


      [落札機械のお引取りについて]<br>
      ・1週間を過ぎて入庫連絡メールが届かない場合、弊社までお問い合わせください。<br>
      ・搬出期限は落札日より3週間となっております。（保管料のご負担はありません）<br>
      ・搬出の際は必ず事前に弊社までメールまたはＦＡＸにてご連絡をお願いいたします。（月曜日～金曜日）<br>
      ・連絡なしでの引取り、当日連絡では出庫対応を致しかねる場合あります。<br>
      「追加作業料」がかかりますのでご注意ください。<br><br>


      ご不明な点は下記にお問い合わせください。<br>
      <br>
      =====================================================<br>
      株式会社　Woody<br>
      電話番号: +81(0)4-7637-6694<br>
      FAX番号 : +81(0)4-7637-6695<br>
      URL : <a class="moz-txt-link-freetext" href="https://auction.woodyengineering.com/">https://auction.woodyengineering.com/</a><br>
      E-Mail: <a class="moz-txt-link-abbreviated" href="mailto:info@woodyengineering.com">info@woodyengineering.com</a><br>
      =====================================================<br>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/mail/auctionBidOwnMail.blade.php ENDPATH**/ ?>