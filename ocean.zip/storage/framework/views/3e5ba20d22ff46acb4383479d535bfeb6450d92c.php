

<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 <?php 
  $base_url = Session::get('base_url');
 ?>
 <section class="breadcrumbs-custom bg-image" style="background-image: url(<?php echo e($base_url); ?>/fontend/images/bg-image-1.jpg)">
    <div class="shell">
      <h2 class="breadcrumbs-custom__title">Fabrication</h2>
      <ul class="breadcrumbs-custom__path">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="active">Fabrication</li>
      </ul>
    </div>
  </section>

<!--============================= Production ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall" data-wow-offset="150">
    <div class="shell-fullwidth">
        <h2 style="text-align: center;">Fabrication Types</h2>
    </div>

    <!-- Owl Carousel-->
    <div class="owl-carousel owl-carousel_style-2" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-dots="true" data-nav="false" data-stage-padding="15" data-loop="true" data-margin="30" data-mouse-drag="false">
      
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item">
        <a class="thumb-corporate" href="<?php echo e(route('fabrication',[$cat->id])); ?>">
          <div class="thumb-corporate__inner"><img src="<?php echo e(asset($cat->image)); ?>" alt="" width="370" height="303"/>
          </div>
          <p class="thumb-corporate__title"><?php echo e($cat->title); ?></p>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
  </div>
</section>





  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/en/category.blade.php ENDPATH**/ ?>