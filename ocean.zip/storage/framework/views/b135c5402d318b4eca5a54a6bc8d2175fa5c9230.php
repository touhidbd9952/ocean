

<?php $__env->startSection('content'); ?>

<style>
    .red{color: red;padding-left:10px;}
    .addnew{cursor: pointer;color: blue;text-decoration: underline;}
</style>    
<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Product</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Sold Product Return As Unsold Form</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    Sold Product Return As Unsold Form
                    <a href="<?php echo e(route('product.view_sold')); ?>"  style="float: right;">View Sold Products</a>
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <strong>Success!</strong> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" style="float:right;">&times;</button>
                        </div>
                    <?php elseif(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <strong>Error!</strong> <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" style="float:right;">&times;</button>
                    </div>    
                    <?php endif; ?>
                    
                      
                    <form action="<?php echo e(route('product.return_as_unsold')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" value="<?php echo e($id); ?>">

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">&nbsp; </label>
                            <div class="col-sm-6">
                                
                                    <img src="<?php echo e(asset($product->thumbnail_image)); ?>" id="output" style="width: 300px;height:225px;margin-top:10px;border:1px solid #ccc;">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label"> Auction No.</label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e($product->product_no); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Category </label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e($product->category->name_en); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Brand </label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e($product->brand->name_en); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Model </label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e($product->model_no); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Serial </label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e($product->serial_no); ?></label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Product Return Reason <span class="red">*</span></label>
                            <div class="col-sm-6">
                                <textarea name="product_return_note" autocomplete="off" class="form-control <?php $__errorArgs = ['product_return_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" ></textarea>
                                <?php $__errorArgs = ['product_return_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-9 offset-md-3">
                                <button type="submit" class="btn btn-primary" style="float: right">
                                    Return To Unsold Product List
                                </button>
                            </div>
                        </div>

                    </form>

                    

                </div>
            </div>

        </div>
    </div>
</div>











<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/backend/admin/product/sold_product_return_as_unsold.blade.php ENDPATH**/ ?>