

<?php $__env->startSection('content'); ?>

<style>
    .dateinputgroup{position: relative;display: flex;flex-wrap: wrap;align-items: stretch;}
    .bootstrap-datetimepicker-widget{min-width: 284px !important;}
    .requireddata{color: rgb(253, 1, 1);}
    .fa-clock::before {content: "\f017";text-align: center;position: relative;left: 130px;}
</style>    
<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Auction</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Auction Edit For Invoice</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    Auction Edit For Invoice
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <strong>Success!</strong> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" style="float:right;">&times;</button>
                        </div>
                    <?php endif; ?>
                    
                    <form action="<?php echo e(route('auction.update_for_invoice',[$product->id])); ?>" method="post" enctype="multipart/form-data" onsubmit="convertnumber()">
                        <?php echo csrf_field(); ?>


                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Product</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->product_no); ?></label>
                                <img src="<?php echo e(asset($product->thumbnail_image)); ?>" id="output" style="width: 300px;height:auto;margin-top:10px;border:1px solid #ccc;">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Category</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->category->name_en); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Brand</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->brand != ""?$product->brand->name_en:""); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Model No.</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->model_no); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Serial No.</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->serial_no); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Model year</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->model_year); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Used hour</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->used_hour); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Buy Price</label>
                            <div class="col-sm-6">
                                <label  class="form-control"><?php echo e($product->buy_price); ?></label>
                            </div>
                        </div>




                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Entry Fee (Product Owner)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="entry_fee" id="entry_fee" onkeyup="commagenerate('entry_fee')" autocomplete="off" class="form-control <?php $__errorArgs = ['entry_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                 value="<?php echo e(number_format((int)$product->entry_fee)); ?>" style="background: #f7eb8b;">
                                <?php $__errorArgs = ['entry_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Inspection Fee (Product Owner)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="inspection_fee" id="inspection_fee" onkeyup="commagenerate('inspection_fee')" autocomplete="off" class="form-control <?php $__errorArgs = ['inspection_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                 value="<?php echo e(number_format((int)$product->inspection_fee)); ?>" style="background: #f7eb8b;">
                                <?php $__errorArgs = ['inspection_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Other Fee (Product Owner)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="other_fee" id="other_fee" onkeyup="commagenerate('other_fee')" autocomplete="off" class="form-control <?php $__errorArgs = ['other_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                 value="<?php echo e(number_format((int)$product->other_fee)); ?>" style="background: #f7eb8b;">
                                <?php $__errorArgs = ['other_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Charge (Bidder)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="auction_charge" id="auction_charge" onkeyup="commagenerate('auction_charge')" value="<?php echo e(number_format((int)$product->auction_charge)); ?>" autocomplete="off" class="form-control <?php $__errorArgs = ['auction_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                style="background: #f7eb8b;">
                                <?php $__errorArgs = ['auction_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Yard Charge (Bidder)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="yard_charge" id="yard_charge" onkeyup="commagenerate('yard_charge')" value="<?php echo e(number_format((int)$product->yard_charge)); ?>" autocomplete="off" class="form-control <?php $__errorArgs = ['yard_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                style="background: #f7eb8b;">
                                <?php $__errorArgs = ['yard_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Extra Charge (Bidder)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="extra_charge" id="extra_charge" onkeyup="commagenerate('extra_charge')" value="<?php echo e(number_format((int)$product->extra_charge)); ?>" autocomplete="off" class="form-control <?php $__errorArgs = ['extra_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                style="background: #f7eb8b;">
                                <?php $__errorArgs = ['extra_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Release Charge (Bidder)<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <input type="text"  name="releasing_charge" id="releasing_charge" onkeyup="commagenerate('releasing_charge')" value="<?php echo e(number_format((int)$product->releasing_charge)); ?>" autocomplete="off" class="form-control <?php $__errorArgs = ['releasing_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                style="background: #f7eb8b;">
                                <?php $__errorArgs = ['releasing_charge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>  </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Auction Bid Start Price<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <label class="form-control"><?php echo e(number_format((int)$product->bid_start_price)); ?></label>
                                
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Bid Increase Amount<span class="requireddata"></span></label>
                            <div class="col-sm-6">
                                <label class="form-control"> <?php echo e(number_format((int)$product->bid_increase_decrease_price)); ?></label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="startdate" class="col-sm-3 text-end control-label col-form-label">Auction Start:<span class="requireddata"></span></label>
                              <div class="col-sm-6 dateinputgroup date" id="datetimepicker1" data-target-input="nearest">
                                <label class="form-control"><?php echo e($product->start_time_of_auction); ?></label>
                                  
                              </div>
                          </div>

                          <div class="form-group row">
                            <label for="startdate" class="col-sm-3 text-end control-label col-form-label">Auction End:<span class="requireddata"></span></label>
                              <div class="col-sm-6 dateinputgroup date" id="datetimepicker2" data-target-input="nearest">
                                <label class="form-control"><?php echo e($product->end_time_of_auction); ?></label>
                              </div>
                          </div>

                        
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-9 offset-md-3">
                                <button type="submit" class="btn btn-primary" style="float: right">
                                    Update For Invoice
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>



<script>
    function convertnumber()
    {
        var entry_fee = document.getElementById('entry_fee').value;
        var inspection_fee = document.getElementById('inspection_fee').value;
        var other_fee = document.getElementById('other_fee').value;

        var auction_charge = document.getElementById('auction_charge').value;
        var yard_charge = document.getElementById('yard_charge').value;
        var extra_charge = document.getElementById('extra_charge').value;
        var releasing_charge = document.getElementById('releasing_charge').value;

        var bid_start_price = document.getElementById('bid_start_price').value;
        var bid_increase_decrease_price = document.getElementById('bid_increase_decrease_price').value;


        document.getElementById('entry_fee').value = entry_fee.replace(/,/g, "");
        document.getElementById('inspection_fee').value = inspection_fee.replace(/,/g, "");
        document.getElementById('other_fee').value = other_fee.replace(/,/g, "");

        document.getElementById('auction_charge').value = auction_charge.replace(/,/g, "");
        document.getElementById('yard_charge').value = yard_charge.replace(/,/g, "");
        document.getElementById('extra_charge').value = extra_charge.replace(/,/g, "");
        document.getElementById('releasing_charge').value = releasing_charge.replace(/,/g, "");

    }
</script>

<script>
    function commagenerate(idname)
    {
        var idvalue = document.getElementById(idname).value;
        if(idvalue !="")
        {
            idvalue = idvalue.replace(/,/g, '');
            if(isNaN(idvalue) == false)
            {
                idvalue = parseInt(idvalue, 10).toLocaleString('en-US'); //alert(idvalue);
                document.getElementById(idname).value = idvalue;	
            }
        }
    }
  </script> 


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/backend/admin/auction/edit_auction_product_for_invoice.blade.php ENDPATH**/ ?>