

<?php $__env->startSection('content'); ?>

<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Product</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Product Image Add More Form</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    Product Image Add More Form
                    <a href="<?php echo e(url('product/imageview/'.$product_id)); ?>"  return false;"  style="float: right;">Back</a>
                </div>

                <div class="card-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <strong>Success!</strong> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" style="float:right;">&times;</button>
                        </div>
                    <?php endif; ?>

                    <form name="myform" action="<?php echo e(url('productimage/addmoreupload')); ?>"  method="POST" enctype="multipart/form-data" class="form-horizontal">

                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="product_id" value="<?php echo e($product_id); ?>">

                        <div class="form-group row">
                            <label for="fname"
                                class="col-sm-3 text-end control-label col-form-label">Product Image</label>
                            <div class="col-sm-9">
                                <input type="file"  name="image[]" id="productmultipleimage"  class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                     multiple>
                                    
                                    <div id="myImg"></div>
                            </div>
                        </div>

                        


                        
                        
                       
                    </div>
                    <div class="border-top">
                        <div class="card-body">
                            <button type="submit" class="btn btn-primary">Upload</button>
                        </div>
                    </div>
                </form>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
    //multiple seleted image show    
    $(function() {
      $("#productmultipleimage").change(function() {
        if (this.files && this.files[0]) {
          for (var i = 0; i < this.files.length; i++) {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[i]);
          }
        }
      });
    });
    
    function imageIsLoaded(e) {
      $('#myImg').append('<img src=' + e.target.result + ' style="width:200px;height:200px">');
    };
</script>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/backend/admin/product/addmore_product_image.blade.php ENDPATH**/ ?>