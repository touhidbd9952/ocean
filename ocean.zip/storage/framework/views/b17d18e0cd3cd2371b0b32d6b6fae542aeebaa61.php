<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 <section class="section swiper-slider_style-1">
  <div class="swiper-container swiper-slider swiper-slider_height-1" data-loop="true" data-autoplay="false" data-simulate-touch="false" data-additional-slides="0" data-custom-prev="#swiper-prev" data-custom-next="#swiper-next" data-custom-slide-effect="interLeaveEffect">
    <div class="swiper-wrapper">
      <div class="swiper-slide context-light">
        <div class="slide-inner" style="background-image: url(fontend/images/slider-1-slide-1-1920x749.jpg);">
          <div class="swiper-slide-caption">
            <div class="shell">
              <h1 data-caption-animate="fadeInUpSmall">Turning <br> Big Ideas</h1>
              <div class="object-decorated"><span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550">into Great Products</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide bg-gray-dark">
        <div class="slide-inner" style="background-image: url(fontend/images/slider-1-slide-2-1920x749.jpg);">
          <div class="swiper-slide-caption">
            <div class="shell">
              <h1 data-caption-animate="fadeInUpSmall">Innovative <br> Technologies</h1>
              <div class="object-decorated"><span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550">for Your Company</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide bg-gray-dark">
        <div class="slide-inner" style="background-image: url(fontend/images/slider-1-slide-3-1920x749.jpg);">
          <div class="swiper-slide-caption">
            <div class="shell">
              <h1 data-caption-animate="fadeInUpSmall">Reliable <br> Solutions</h1>
              <div class="object-decorated"> <span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550">for Industrial Environment</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="swiper-pagination"></div>
  </div>
  <div class="swiper-navigation swiper-navigation_modern">
    <div class="swiper-button-prev" id="swiper-prev"></div>
    <div class="swiper-button-next" id="swiper-next"></div>
  </div>
</section>

<!--============================= Production ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall" data-wow-offset="150">
    <!-- Owl Carousel-->
    <div class="owl-carousel owl-carousel_style-2" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-dots="true" data-nav="false" data-stage-padding="15" data-loop="true" data-margin="30" data-mouse-drag="false">
      <?php 
        for($i=0;$i<4;$i++)
        {
      ?>
      <div class="item">
        <a class="thumb-corporate" href="<?php echo e(route('production.view')); ?>">
          <div class="thumb-corporate__inner"><img src="<?php echo e(asset('fontend')); ?>/images/production-preview-1-370x303.jpg" alt="" width="370" height="303"/>
          </div>
          <p class="thumb-corporate__title">Building Technologies</p>
        </a>
      </div>
      <?php 
      }
      ?>
    </div>
  </div>
</section>


<!--====================== Our Projects ========================================-->
<section class="section section-md bg-white text-center">
  <div class="shell-fullwidth">
    <h2>Our Projects</h2>
    <!-- Owl Carousel-->
    <div class="owl-carousel owl-carousel_style-2 wow fadeIn" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-dots="true" data-nav="true" data-loop="true" data-stage-padding="0" data-sm-stage-padding="20" data-md-stage-padding="0" data-sm-margin="15" data-lg-margin="0" data-mouse-drag="false">
      <div class="thumb-janez">
        <figure class="thumb-janez__image-wrap"><img src="<?php echo e(asset('fontend')); ?>/images/project-1-481x383.jpg" alt="" width="481" height="383"/>
        </figure>
        <div class="thumb-janez__content bg-gray-dark">
          <div class="thumb-janez__content-inner">
            <h5><a href="#">Metal Fabrication</a></h5>
            <p>We often supply our customers with reliable metal fabrication solutions including custom products.</p><a class="button button-xs button-darker" href="#">read more</a>
          </div>
        </div>
      </div>
      <div class="thumb-janez">
        <figure class="thumb-janez__image-wrap"><img src="<?php echo e(asset('fontend')); ?>/images/project-2-481x383.jpg" alt="" width="481" height="383"/>
        </figure>
        <div class="thumb-janez__content bg-gray-dark">
          <div class="thumb-janez__content-inner">
            <h5><a href="#">Construction</a></h5>
            <p>This recent project marks the 10th anniversary of our cooperation with the construction industry.</p><a class="button button-xs button-darker" href="#">read more</a>
          </div>
        </div>
      </div>
      <div class="thumb-janez">
        <figure class="thumb-janez__image-wrap"><img src="<?php echo e(asset('fontend')); ?>/images/project-3-481x383.jpg" alt="" width="481" height="383"/>
        </figure>
        <div class="thumb-janez__content bg-gray-dark">
          <div class="thumb-janez__content-inner">
            <h5><a href="#">Transportation</a></h5>
            <p>Transportation companies use our solutions to provide uninterrupted container shipping.</p><a class="button button-xs button-darker" href="#">read more</a>
          </div>
        </div>
      </div>
      <div class="thumb-janez">
        <figure class="thumb-janez__image-wrap"><img src="<?php echo e(asset('fontend')); ?>/images/project-4-480x383.jpg" alt="" width="480" height="383"/>
        </figure>
        <div class="thumb-janez__content bg-gray-dark">
          <div class="thumb-janez__content-inner">
            <h5><a href="#">Custom Solutions</a></h5>
            <p>We provide custom heavy industrial products and services to our clients worldwide.</p><a class="button button-xs button-darker" href="#">read more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/welcome.blade.php ENDPATH**/ ?>