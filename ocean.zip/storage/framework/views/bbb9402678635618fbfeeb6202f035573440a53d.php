

<?php $__env->startSection('content'); ?>

<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Auction History</h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Auction List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    Auction List
                    <a href="<?php echo e(route('customer.searchpage')); ?>" style="float: right;">Customer Invoice</a>
                    <a href="<?php echo e(route('owner.searchpage')); ?>" style="float: right;margin-right:15px;">Owner Invoice</a>
                </div>

                <div class="card-body">
                    
                    <div class="table-responsive">
                        <table id="example" border="1" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th style="min-width: 150px">Auction Name</th>
                                    <th style="min-width: 150px">Start Date</th>
                                    <th style="min-width: 150px">End Date</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $sl=1;
                            ?>
                            <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl++); ?></td>
                                    <td><?php echo e($b->name); ?></td>
                                    <td><?php echo e($b->start_time_of_auction); ?></td>
                                    <td><?php echo e($b->end_time_of_auction); ?></td>
                                    
                                    <td style="min-width: 500px;">
                                        <a href="<?php echo e(url('auction/history/'.$b->id)); ?>" class="btn btn-success">Show Data</a>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                            
                        </table>

                        

                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/backend/admin/product/history.blade.php ENDPATH**/ ?>