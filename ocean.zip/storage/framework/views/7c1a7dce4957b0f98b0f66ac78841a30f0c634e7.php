

<?php $__env->startSection('code', '404 😭'); ?>

<?php $__env->startSection('title', __('Page Not Found')); ?>

<?php $__env->startSection('image'); ?>

<div style="max-width: 300px;margin:0 auto">
    <h1>Error 404 — Not Found 
        <br>
        <br>
        Sorry, the page you are looking for could not be found</h1>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('Sorry, the page you are looking for could not be found.')); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freeman\resources\views/errors/404.blade.php ENDPATH**/ ?>