

<?php $__env->startSection('content'); ?>


<!-- Breadcrumbs-->
<section class="breadcrumbs-custom bg-image" style="background-image: url(fontend/images/bg-image-1.jpg);">
    <div class="shell">
      <h2 class="breadcrumbs-custom__title">About Us</h2>
      <ul class="breadcrumbs-custom__path">
        <li><a href="index.html">Home</a></li>
        <li class="active">About Us</li>
      </ul>
    </div>
  </section>

  <!-- Experience since 1999-->
  <section class="section section-md bg-white">
    <div class="shell">
      <div class="range range-70 range-sm-center range-lg-justify">
        <div class="cell-sm-10 cell-md-6 cell-lg-5">
          <h4>Experience since 1999</h4>
          <p>Alfa Industries is the leading provider of specialty services to North America's process industries.</p>
          <p>Our company was founded in 1999 as a local enterprise manufacturing various products and providing services for other industrial companies. We focus on long-term and sustainable development concepts.</p>
          <h4>Our Mission</h4>
          <p>We provide the highest-quality end products to our customers, while striving to make them the leaders in their respective industries.</p>
        </div>
        <div class="cell-sm-10 cell-md-6">
          <div class="row grid-2">
            <div class="col-xs-6"><img src="<?php echo e(asset('fontend')); ?>/images/about-1-273x214.jpg" alt="" width="273" height="214"/><img src="<?php echo e(asset('fontend')); ?>/images/about-2-273x214.jpg" alt="" width="273" height="214"/>
            </div>
            <div class="col-xs-6"><img src="<?php echo e(asset('fontend')); ?>/images/about-3-273x451.jpg" alt="" width="273" height="451"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Our History -->
  <section class="section parallax-container bg-gray-dark">
    <div class="material-parallax"><img src="<?php echo e(asset('fontend')); ?>/images/parallax-2.jpg" alt=""/></div>
    <div class="parallax-content">
      <div class="section-md text-center">
        <div class="shell">
          <h2>Our History</h2>
          <div class="timeline"> 
            <div class="timeline__item-wrap">
              <!-- Timeline item-->
              <article class="timeline__item">
                <div class="timeline__item-header">
                  <h5>Idea,1999</h5>
                </div>
                <div class="timeline__item-main"><img src="<?php echo e(asset('fontend')); ?>/images/about-4-93x86.jpg" alt="" width="93" height="86"/>
                  <p>We started to provide top-notch manufacturing services for our clients.</p>
                </div>
              </article>
            </div>
            <div class="timeline__item-wrap">
              <!-- Timeline item-->
              <article class="timeline__item timeline__item-reverse">
                <div class="timeline__item-header">
                  <h5>Production,2005</h5>
                </div>
                <div class="timeline__item-main"><img src="<?php echo e(asset('fontend')); ?>/images/about-5-93x86.jpg" alt="" width="93" height="86"/>
                  <p>We greatly increased the level of production and sales of metal products.</p>
                </div>
              </article>
            </div>
            <div class="timeline__item-wrap">
              <!-- Timeline item-->
              <article class="timeline__item">
                <div class="timeline__item-header">
                  <h5>Industry Leader,2016</h5>
                </div>
                <div class="timeline__item-main"><img src="<?php echo e(asset('fontend')); ?>/images/about-6-93x86.jpg" alt="" width="93" height="86"/>
                  <p>In 2016, we were recognized as the industry leader in the USA.</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- Social Responsibility & Eco Standards-->
  <section class="section section-sm bg-white">
    <div class="shell">
      <div class="range range-50 range-sm-center range-md-left range-lg-justify">
        <div class="cell-sm-10 cell-md-6">
          <h4>Social Responsibility</h4>
          <p>We are glad to define ourselves as one of socially responsible companies. At Alfa Industries, we understand we’re a part of our community and do everything to support it.</p>
          <div class="group-3-columns" data-lightgallery="group">
            <div class="column-item"><a class="thumb-elegant" href="images/image-1-1200x803_original.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/image-1-166x139.jpg" alt="" width="166" height="139"/>
                <div class="thumb-elegant__overlay"></div></a></div>
            <div class="column-item"><a class="thumb-elegant" href="images/image-2-1200x809_original.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/image-2-166x139.jpg" alt="" width="166" height="139"/>
                <div class="thumb-elegant__overlay"></div></a></div>
            <div class="column-item"><a class="thumb-elegant" href="images/image-3-1200x800_original.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/image-3-166x139.jpg" alt="" width="166" height="139"/>
                <div class="thumb-elegant__overlay"></div></a></div>
          </div>
        </div>
        <div class="cell-sm-10 cell-md-6 cell-lg-5">
          <h4>Eco Standards</h4>
          <p>Here are our environmental certificates that regulate the standards of our environmental cooperation.</p>
          <div class="group-3-columns" style="max-width: 430px;" data-lightgallery="group"> 
            <div class="column-item"><a class="thumb-light" href="images/certificate-1-847x1200.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/certificate-1-120x171.jpg" alt="" width="120" height="171"/>
                <div class="thumb-light__overlay"></div></a></div>
            <div class="column-item"><a class="thumb-light" href="images/certificate-1-847x1200.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/certificate-1-120x171.jpg" alt="" width="120" height="171"/>
                <div class="thumb-light__overlay"></div></a></div>
            <div class="column-item"><a class="thumb-light" href="images/certificate-1-847x1200.jpg" data-lightgallery="group-item"><img src="<?php echo e(asset('fontend')); ?>/images/certificate-1-120x171.jpg" alt="" width="120" height="171"/>
                <div class="thumb-light__overlay"></div></a></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Top Management-->
  <section class="section section-md bg-gray-4">
    <div class="shell">
      <!-- Section Header-->
      <div class="section__header">
        <h4>Top Management</h4>
        <div class="section__header-element"><a class="link link-medium" href="contacts.html">Contact Us</a></div>
      </div>
      <div class="range range-30">
        <div class="cell-sm-6 cell-md-4">
          <!-- Card creative-->
          <article class="card-creative">
            <div class="card-creative__header"><img src="<?php echo e(asset('fontend')); ?>/images/top-management-1-115x119.jpg" alt="" width="115" height="119"/>
            </div>
            <div class="card-creative__main" data-fixed-height="">
              <p class="card-creative__title">Sam Wilson</p>
              <p class="card-creative__subtitle">CEO “Alfa Industries”</p>
              <div class="card-creative__element"><a href="mailto:#">info@demolink.org</a></div>
            </div>
          </article>
        </div>
        <div class="cell-sm-6 cell-md-4">
          <!-- Card creative-->
          <article class="card-creative">
            <div class="card-creative__header"><img src="<?php echo e(asset('fontend')); ?>/images/top-management-2-115x119.jpg" alt="" width="115" height="119"/>
            </div>
            <div class="card-creative__main" data-fixed-height="">
              <p class="card-creative__title">Jim Lee</p>
              <p class="card-creative__subtitle">Head of Innovation Department</p>
              <div class="card-creative__element"><a href="mailto:#">info@demolink.org</a></div>
            </div>
          </article>
        </div>
        <div class="cell-sm-6 cell-md-4">
          <!-- Card creative-->
          <article class="card-creative">
            <div class="card-creative__header"><img src="<?php echo e(asset('fontend')); ?>/images/top-management-3-115x119.jpg" alt="" width="115" height="119"/>
            </div>
            <div class="card-creative__main" data-fixed-height="">
              <p class="card-creative__title">Peter Wilson</p>
              <p class="card-creative__subtitle">Head of Purchasing</p>
              <div class="card-creative__element"><a href="mailto:#">info@demolink.org</a></div>
            </div>
          </article>
        </div>
      </div>
    </div>
  </section>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/aboutus.blade.php ENDPATH**/ ?>