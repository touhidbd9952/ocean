

<?php $__env->startSection('content'); ?>


<!-- Breadcrumbs-->
<?php 
$base_url = Session::get('base_url');
?>
<section class="breadcrumbs-custom bg-image" style="background-image: url(<?php echo e($base_url); ?>/fontend/images/bg-image-1.jpg)">
    <div class="shell">
      <h2 class="breadcrumbs-custom__title">会社概要</h2>
      <ul class="breadcrumbs-custom__path">
        <li><a href="index.html">ホーム</a></li>
        <li class="active">会社概要</li>
      </ul>
    </div>
  </section>

  <!-- Experience since 1999-->
  <section class="section section-md bg-white">
    <div class="shell">
      <div class="range range-70 range-sm-center range-lg-justify">
        <div class="cell-sm-10 cell-md-6 cell-lg-5">
          <h4>1991年以来の経験</h4>
          <p>
            ウッディーは1991年12月に資本金30,000,000円で設立しました。それ以来、会社は成長しています。  
          </p>
          <p>
            私たちはフォークリフトや掘削機械、土木建築機械の買取、販売、輸出入を行っています。
          </p>
          <h4>Our Mission</h4>
          <p>何年間もにわたって、ウッディーは世界中のお客様のお手伝いをし、信頼の上で成り立ったよいビジネスを構築しています</p>
        </div>


        <div class="cell-sm-10 cell-md-6">
          <div class="row grid-2">
            <div class="col-xs-6">
              <img src="<?php echo e(asset('fontend')); ?>/images/wilding-1.jpg" alt="" style="width: 273px;height: 214px;"/>
              <img src="<?php echo e(asset('fontend')); ?>/images/factory.jpg" alt="" style="width: 273px;height: 214px;"/>
            </div>
            <div class="col-xs-6">
              <img src="<?php echo e(asset('fontend')); ?>/images/grapple.jpg" alt="" style="width: 273px;height: 214px;"/>
              <img src="<?php echo e(asset('fontend')); ?>/images/factory-2.jpg" alt="" style="width: 273px;height: 214px;"/>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/jp/aboutus.blade.php ENDPATH**/ ?>