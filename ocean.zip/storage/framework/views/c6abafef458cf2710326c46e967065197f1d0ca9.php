

<?php $__env->startSection('content'); ?>
 <!-- Swiper -->
 <!-- Breadcrumbs-->

<!--=============================  ======================================-->
<style>
    #myDIV {
      width: 100%;
      padding: 50px 0;
      text-align: center;
      background-color: lightblue;
      margin-top: 20px;
    }
    .section-div{margin-bottom: 15px;}
    .headertitle{display: block;text-align:center;font-weight:bold;font-size: 16px;color:#F5A641;background: #f4f3f3;}
    .menudiv{background: #F5A641;color:#f4f3f3;display:block;text-align:center;font-weight:bold;margin-bottom:5px;}
    .menudiv:hover, .menudiv:focus {background: #f3d3aa;color:#f4f3f3;text-decoration: none;outline: none;}
    .section-div p{margin-top: 10px;font-size:14px;}
    .section-div p, ul li, ol li{color: #000 !important;}
    .section-div p b{font-size: 16px;color: #000 !important;}
    p b{font-size: 16px;color: #000 !important;}
    p{color: #000 !important;}
    .section-div b{font-size: 16px;color: #000 !important;}
    .fa-circle{padding-right: 10px;color: #F5A641;}
</style>
<script>
    function myFunction(myDIV) {
      var x = document.getElementById(""+myDIV);
      if (x.style.display === "none") 
      {
        x.style.display = "block";
      } 
      else 
      {
        x.style.display = "none";
      }
    }
</script>

<script> 
function showmenu(menudiv)
{ 
    
    document.getElementById("menudiv1").style.display = "none";  
    document.getElementById("menudiv2").style.display = "none"; 
    document.getElementById("menudiv3").style.display = "none"; 
    document.getElementById("menudiv4").style.display = "none"; 

    document.getElementById(""+menudiv).style.display = "block";
    
}
</script>    

<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
  <div class="cat-items-grid">
  <section id="home" class="home-page-content page-content">
      <section class="products-section">
      <div class="container">
        <div class="row"> 
            <div class="col-md-12"> 
                <div style="width: 100%;min-height:50px;">
                    <div class="col-md-3">
                        <a href="javascript:" class="menudiv" onclick="showmenu('menudiv1')">Bidding Style</a>
                    </div>
                    <div class="col-md-3">
                        <a href="javascript:" class="menudiv" onclick="showmenu('menudiv2')">Log-in & Bedding</a>
                    </div>
                    <div class="col-md-3">
                        <a href="javascript:" class="menudiv" onclick="showmenu('menudiv3')">Target Machines Selection</a>
                    </div>
                    <div class="col-md-3">
                        <a href="javascript:" class="menudiv" onclick="showmenu('menudiv4')">Carry-Out of Equipment</a>
                    </div>
                </div>    
            </div>  

            <!---======== start =========---->
            <div id="menudiv1" class="col-md-12" style="display:block"> 
            <h4>Bidding Style</h4>
            <br><br>

            <div class="section-div"> 
                <a href="javascript:" onclick="myFunction('menudiv1myDIV1')" class="headertitle">Bidding Up Style </a>
                <div id="menudiv1myDIV1" style="display:none">
                   <p>
                    Auction can have Plural bidders that bid up the price of each item and this way the Highest Bidder at the Auction Close Time becomes the Winner. When plural bidders bid on the same item before the Auction Close, the Auction Time for this item is extended automatically.
                   </p>
                </div>
            </div>

            <div class="section-div"> 
                <a href="javascript:" onclick="myFunction('menudiv1myDIV2')" class="headertitle">Automatic Bid System </a>
                <div id="menudiv1myDIV2" style="display:none">
                     <p>
                        A bidder can Bid with Maximum Amount (AUTOBID) on auction item until Auction Close. Maximum Bid Amount of a Bidder is NOT shown to other bidders. 
                        The item can be won at less than the planned maximum amount of money as long as the subject price is not surpassed by those of other bidders. When Bidder wants to bid on plural items, Bidder can manage to bid on each item more easily by using AUTOBID when Auction Close draws near.
                     </p>
                </div>
            </div>

            <div class="section-div"> 
                <a href="javascript:" onclick="myFunction('menudiv1myDIV3')" class="headertitle">Automatic Extension of Auction </a>
                <div id="menudiv1myDIV3" style="display:none">
                   <p>
                    If a Bid is placed when the remaining time is 2 minutes or less before the Auction Closing Time, Auction time will be extended for 2 minutes. After the first extension.
                   </p>
                </div>
            </div>

            


            </div>
            <!---======== end =========---->




            <!---======== start =========---->
            <div id="menudiv2" class="col-md-12" style="display: none"> 
                <h4>How to Log-in & Bedding</h4>
                <br>
    
                <p>
                    <b><i class="fas fa-circle"></i>Enter User ID and Password to Login your Auction</b>
                    <ol>
                    <li>
                        You can login by using User ID and Password from "Auction Product Items List" Page or "Item Details" Page. After successful Login you can start bidding. 
                        <br>
                        <img src="<?php echo e('fontend/images/document/login.jpg'); ?>" style="max-width:700px;">
                    </li>
                </p>

                <p>
                    <b><i class="fas fa-circle"></i>Bidding</b>
                    <ol>
                    <li>
                        Now you can bid from " Auction Product Item List page" and "Item Detail page", Click “+" sign Button and "Increment Amount" to set new Bid Price and then click "Bid" Button.
                        (At this point Bidding has not yet been completed.)
                        <br>
                        <img src="<?php echo e('fontend/images/document/bidding.jpg'); ?>" style="max-width:700px;">
                    </li>
                </p>

                <p>
                    <b><i class="fas fa-circle"></i>Confirmation Page</b>
                    <ol>
                    <li>
                        Click "Confirm Bid" Button to confirm Bid Price.
                        <br>
                        <img src="<?php echo e('fontend/images/document/bidconfirm.jpg'); ?>" style="max-width:700px;">
                        <br><br>
                    </li>
                </p>

                <p>
                    <b><i class="fas fa-circle"></i>Bid Status page</b>
                    <ol>
                    <li>
                        If you turn out to be the Highest Bidder.
                        <br>
                        <img src="<?php echo e('fontend/images/document/bidstatus.jpg'); ?>" style="max-width:700px;">
                    </li>
                </p>

                <p>
                    <ol>
                    <li>
                        If you want to bid on another item, click on "Back to LIST" button.<br>
                        Win bidder will see below green message
                        <br>
                        <img src="<?php echo e('fontend/images/document/winbidmessage.jpg'); ?>" style="max-width:700px;">
                    </li>
                </p>

                <p>
                    <ol>
                    <li>
                        Looser bidder will see below red message
                        <br>
                        <img src="<?php echo e('fontend/images/document/losebidmessage.jpg'); ?>" style="max-width:700px;">
                    </li>
                </p>

                <p>
                    <ol>
                    <li>
                        If bidder click on  "Back to BIDDING & DETAIL PAGE", then software will show the previous auction details page.
                    </li>
                </p>

                <p>
                    <ol>
                    <li>
                        When we have accepted Your Bid, we will send you "Bid Accepted" e-mail.
                        <br>
                        When you have got OUTBIDDEN, we will send you "You were OUTBIDDEN" e-mail.
                    </li>
                </p>

            </div>
            <!---======== end =========---->


            <!---======== start =========---->
            <div id="menudiv3" class="col-md-12" style="display: none"> 
                <h4>Target Machines Selection</h4>
                <br>
    
                <div>
                   <img src="<?php echo e('fontend/images/document/selecteditems.jpg'); ?>" style="max-width:700px;display:">
                </div>
                <div style="color: #000;">
                    <br>
                    <b style="font-size: 16px;">About Selections (★)</b>
                    <br>
                    After Login, when you click on   
                    <img src="<?php echo e('fontend/images/document/addtoselection.jpg'); ?>" style="max-width:700px;display:inline;">
                    top to item photo, the mark turns to   
                    <img src="<?php echo e('fontend/images/document/removefromselection.jpg'); ?>" style="max-width:700px;display:inline;">
                    and the item is added in "Selections" list. 

                    <br><br>
                    <b style="font-size: 16px;">Selections</b> <br>
                    When you click on "Selections" Button, only Selected Items (★) will show.
                    <br><br>

                    <b style="font-size: 16px;">Result of Selections</b> <br>
                    After Auction Close you can see the results of your bidding on the items. 
                    <br><br>

                    <b style="font-size: 16px;">Category List</b> <br>
                    Select a category that you want to see before auction.
                    <br><br>

                    <b style="font-size: 16px;">Item Search</b> <br>
                    Search auction item by Model name, Auction No., and Delivery yard area. 
                    <br><br>

                    <b style="font-size: 16px;">Choice</b><br>
                    •	"All" will show All Items. <br>
                    •	"New Today" will show only the items just uploaded the current day.<br>
                    •	"End Soon" will show only the items whose auction close the current day. <br>

                    
                </div>
            </div>
            <!---======== end =========---->

            <!---======== start =========---->
            <div id="menudiv4" class="col-md-12" style="display: none"> 
                <h4>Carry-Out of Equipment</h4>
                <br>
                <p><i class="fas fa-circle"></i>The Successful Bidder is required to give WOODY an advance notice, by the previous day of the Carry-Out, about the date and time, and transport company name of the purchased item. 
                (Please do not contact the Yard Staff directly.）</p> 
                <br>
                <p>	<i class="fas fa-circle"></i>When there is No advance notice the equipment connot be carried out.
                Due to inovitable reasons, he/she may do Carry-Out bat with the payment of "Extra Work Charge" of JPY5,000. 
                <br>
                Phone:+81(0)3-5700-4622　E-mail:all@woodyltd.com <br>
                <p>	<i class="fas fa-circle"></i>We may be forced to decline the Carry-Out by the Successful Bidder, if he/she comes with a non-law-abiding vehicle, unsafe truck or trailer. </p>
                <p>	<i class="fas fa-circle"></i>In Case that the Equipment has already [Arrived] at the Delivery Yard by the time of Auction Entry </p>
                <p>The Successful Bidder is requested to make payment within one week and to carry out the purchased Equipment within two weeks from the Auction Close Day.
                If Carry-Out is not executed by the above deadline, the Storage Fee is chargeable on the Successful Bidder.</p>
                <p>	<i class="fas fa-circle"></i>In Case that the Equipment is still [Coming] to the Delivery Yard at the time of Auction Entry </p>
                
                <p><i class="fas fa-circle"></i>The purchased equipment by the Successful Bidder will arrive in WOODY's Designated Delivery Yard within One Week.
                The Successful Bidder is requested to carry out hie/her equipment within three weeks from the Auction Close including the period neccesary for its transnport into the Delivery Yard. If Carry-Out is not executed by the above deadline, the Storage Fee is chargeable on the Successful Bidder.</p>
                <p>	<i class="fas fa-circle"></i>In Case of Carry-Out from "Consigner’s Own Yard" 
                When Successful Bidder is an Overseas Auction Member
                After the Successful Bidding the purchased Equipment is transported to one of WOODY-Designated Forwarders' Yards. The Successful Bidder will be billed for Inland Trucking Charge specified in the INVOICE.
                When Successful Bidder is a Domestic Auction Member</p>
                <p> <i class="fas fa-circle"></i>Carry-Out is done in terms of Freight On Board. </p>
                <p> <i class="fas fa-circle"></i>The successful Bidder is required to follow WOODY's instructions.
                The Successful Bidder CANNOT contact the Consigner directly to carry out his/her equipment.</p>
                <p>  <i class="fas fa-circle"></i>If Carry-Out is not executed within two weeks after the Auction Close, WOODY will transfer
                the equipment to WOODY's Designated Delivery Yard.The Successful Bidder is responsible for
                all the cost incurred from such operation. </p>
                <p>  <i class="fas fa-circle"></i>After three weeks from the Auction Day we shall not be responsible for safe storage
                of Equipment. </p>
                <p>	<i class="fas fa-circle"></i>In Case of Carry-Out from "Consigner’s Own Yard" </p>
                <p> <i class="fas fa-circle"></i>When Successful Bidder is a Domestic Auction Member</p>
                <p>	<i class="fas fa-circle"></i>The Successful Bidder shall be responsible for all the accidents and/or troubles taking place at the time of and after the Carry-Out. WOODY shall be exempted from such responsibility. </p>
                <p>	<i class="fas fa-circle"></i>The Successful Bidder shall be responsible for all damages or losses (e.g. sticking, rust, oil leakage,damage to electric system) incurred after the Auction, caused fy any reasons including lapse of time, weather, etc. </p>
            </div>
            <!---======== end =========---->

        </div>
      </div>
      </section>
      </section>
  </div>
  </div>
</section>





  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/fontend/jp/documents/workflow.blade.php ENDPATH**/ ?>