

<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 

<!--=============================  ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
    
    <style>
      .header_title{font-size: 18px !important;}
      
    .msgstyle{padding: 15px;border: 1px solid #fbbd05;text-align: center;}
    .backlink{color: #fbb206;font-weight: bold;font-size: 18px;}
    .panel-primary {border-color: #F5A85F;}
    .redcolor{background: #FF0000;color: #FFFFFF;border: solid 1px #FF0000;border-radius: 10px;padding: 0.0em 0.5em;font-weight: bold;}
  </style>    
  
  <div class="cat-items-grid">
  <section id="home" class="home-page-content page-content">

      
    <?php 
    $auction_date =  date('Y-m-d',strtotime(App\Models\Product::max('auction_date')));  
    $auction_dates = App\Models\Product::distinct('auction_date')->where('auction_date','not like', '%'.$auction_date.'%')->orderby('auction_date','desc')->get();  //dd($auction_dates);
    ?>
    
      
      <section class="products-section">
      <div class="container">
        <div class="row">  


        <div class="col-md-12">
            <a href="<?php echo e(route('woody.search_site_logout')); ?>" class="btn btn-primary" style="float: right;margin-top:-50px;">Logout</a>
         
          <table  class="table table-striped table-bordered" style="max-height:600px;height:auto;overflow-y: scroll;">
            
        <?php $__currentLoopData = $auction_dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
          <?php 
          if($acs->final_result == 'sold')
          {
          ?>
         <tr>
          <td>
              <a href="<?php echo e(url('search_site/bid_result/'.date('Y-m-d',strtotime($acs->auction_date)))); ?>">
                <span class="redcolor">
                Auction Information
                </span>
              </a>
          </td>
          <td><a href="<?php echo e(url('search_site/bid_result/'.date('Y-m-d',strtotime($acs->auction_date)))); ?>"><?php echo e(date('Y-m-d',strtotime($acs->auction_date))); ?></a></td>
         </tr>
         <?php 
          }
         ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </table>
            
         
        </div>
        

        

       </div>
      
      </div>
      </section>
      
      
      </section>
  </div>
    
    
  </div>
</section>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/fontend/en/search_site_auction.blade.php ENDPATH**/ ?>