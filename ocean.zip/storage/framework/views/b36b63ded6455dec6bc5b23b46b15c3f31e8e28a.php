<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 <section class="section swiper-slider_style-1">
  <div class="swiper-container swiper-slider swiper-slider_height-1" data-loop="true" data-autoplay="false" data-simulate-touch="false" data-additional-slides="0" data-custom-prev="#swiper-prev" data-custom-next="#swiper-next" data-custom-slide-effect="interLeaveEffect">
    <div class="swiper-wrapper">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
      <div class="swiper-slide context-light">
        <div class="slide-inner" style="background-image: url(<?php echo e($slider->slider_image); ?>);">
          <div class="swiper-slide-caption">
            <div class="shell">
            <?php  
              if(session()->get('language')=='en')
              {
            ?>
              <h1 data-caption-animate="fadeInUpSmall" style="color: #fff;"><?php echo e($slider->title); ?></h1>
              <div class="object-decorated">
                <?php 
                  if($slider->subtitle != "")
                  {
                ?>
                <span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550" style="color: #fff;"><?php echo e($slider->subtitle); ?></h4>
             <?php 
                  }
              }
              else {
              ?>
              <h1 data-caption-animate="fadeInUpSmall" style="color: #fff;"><?php echo e($slider->title_jp); ?></h1>
              <div class="object-decorated"><span class="object-decorated__divider" data-caption-animate="fadeInRightSmall" data-caption-delay="300"></span>
                <h4 data-caption-animate="fadeInRightSmall" data-caption-delay="550" style="color: #fff;"><?php echo e($slider->subtitle_jp); ?></h4>
              <?php   
              }
             ?>   
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     

      

    </div>
    <div class="swiper-pagination"></div>
  </div>
  <div class="swiper-navigation swiper-navigation_modern">
    <div class="swiper-button-prev" id="swiper-prev"></div>
    <div class="swiper-button-next" id="swiper-next"></div>
  </div>
</section>

<!--=============================  ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall" data-wow-offset="150">
    
    <style>
      .header_title{font-size: 18px !important;}
      .pl0{padding-left: 0px;}
      .pr0{padding-right: 0px;}
      .w100{width: 100%;}
      .choice ul{list-style-type: none;padding-left:0px;}
      .choice ul li{display: inline;height:20px;margin:6px 1em;}
      .choice ul li a.selected{color: #fff;background:rgb(41, 174, 108);padding: 0 5px;}
      .choice ul li a.newtoday{color: #f4b906;}
      .choice ul li a.endsoon{color: #ff0404;}
      .pmr{padding-right: 0px;}
      .tablegap{background: #fff;width:100%;height: 15px;border-top: 1px solid #ccc;}
      .table {width: 100%;max-width: 100%;margin-bottom: 0px !important;}
      input.reload {float:right;width: 96px;height: 35px;padding: auto;background: #ff8c00;color: #fff;background-size: auto;-webkit-background-size: 32px;-moz-background-size: 32px;-ms-background-size: 32px;background-size: 32px;font-size: 13px;margin: 0 auto;}
      input.bid {float: right;width: 96px;height: 35px;background: #1b9f36;color: #fff;font-weight: bold;}
      @media(max-width:767px)
      {
          .pmr{padding-right: 15px;}
      }
  </style>    
  
  <div class="col-md-9 cat-items-grid">
  <section id="home" class="home-page-content page-content">
      <section class="homepage-slider">
      <div class="container">
      
      <div class="homeCarousel flexslider" data-animation="fade" data-slideshowspeed="2000">
      <ul class="slides">
      
      <li style="width: 100%; float: left; margin-right: -100%; position: relative; opacity: 1; display: block; z-index: 2;" class="flex-active-slide">
          <a href=""><img src="<?php echo e(asset('fontend')); ?>/img/oldimg/banner1.jpg" alt="banners" draggable="false" style="max-height: 80px;width: 100%;"></a></li>
      
      </ul>
      <ul class="flex-direction-nav">
          <li class="flex-nav-prev"><a class="flex-prev flex-disabled" href="#" tabindex="-1">Previous</a></li>
          <li class="flex-nav-next"><a class="flex-next flex-disabled" href="#" tabindex="-1">Next</a></li></ul></div>
      
      </div>
      </section>
      
      
      <section class="products-section">
      <div class="container">
         <div style="width: 100%;min-height:100px;border:1px solid #ccc;padding:10px;">  
              <form>
                  <div class="form-group row">
                      <div class="col-sm-12 col-xs-12">
                          <label  class="header_title">Item Search</label>
                      </div>
                      
                      <div class="col-sm-12">
                          <div class="row">
                              <div class="col-sm-3 col-xs-6  pr0">
                                  <label  class="border_none w100">MODEL：</label>
                                  <input type="text" name="" class="w100" >
                              </div>
  
                              <div class="col-sm-3 col-xs-6  pmr">
                                  <label  class="border_none w100">Auction No.：</label>
                                  <input type="text" name="" class="w100">
                              </div>
  
                              <div class="col-sm-3 col-xs-6  pr0">
                                  <label  class="border_none w100">Delivery Area：</label>
                                  <select name="MODEL_ITEM_S_DELIYARD" class="w100">
                                      <option value="" selected="selected">---</option>
                                      <option value="Narita">Narita</option>
                                      <option value="Kobe">Kobe</option>
                                      <option value="Tomakomai">Tomakomai</option>
                                      <option value="Osaka">Osaka</option>
                                      <option value="Yokohama">Yokohama</option>
                                      <option value="Kikugawa(Shizuoka Prf.)">Kikugawa</option>
                                      <option value="Koga">Koga</option>
                                      <option value="Hakata">Hakata</option>
                                      <option value="Fukuoka">Fukuoka(Shingu)</option>
                                      <option value="Consignor">Consignor's</option>
                                      
                                  </select>
                              </div>
                              <div class="col-sm-3 col-xs-6">
                                  <label  class="border_none w100">&nbsp;</label>
                                  <input type="submit" value="Search" style="width:80px;">
                              </div>
                          </div>
                      </div>
                  </div>
              </form>
              <hr>
  
                  <div class="form-group row">
                     <div class="col-sm-12 choice"> 
                      <div style="width: 60px;float: left;"><label>Choice:</label></div>
                      <div style="width: 300px;float: left;">
                      <ul>
                          <li><a href="" class="all selected">ALL</a></li>
                          <li><a href="" class="newtoday">New Today!</a></li>
                          <li><a href="" class="endsoon">End soon!</a></li>
                      </ul>
                      </div>
                     </div> 
                  </div>    
         </div>
  
         <div style="width: 100%;min-height:100px;border:1px solid #ccc;padding:10px;margin-top:15px;">
          <div class="form-group row">
              <div class="col-md-12 choice">
                  <div class="table-responsive">
                      <table id="example2" class="table table-striped">
                          <thead>
                              <tr>
                                  <th>
                                      <?php echo e($auctionproducts->links()); ?>

                                  </th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td style="background: #fff;">
                                      
                                      <?php $__empty_1 = true; $__currentLoopData = $auctionproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actionpro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                          <?php 
  
  
                                              ///////time left calculation start////////
                                              $auction_startdate = strtotime($actionpro->start_time_of_auction);
                                              $auction_enddate = strtotime($actionpro->end_time_of_auction);
                                              $today_date = strtotime(Illuminate\Support\Carbon::now());
                                              $timeduration="";
                                              $day = 86400;
                                              $hour = 3600;
                                              $minute = 60;
                                              $daysout=0;
                                              $hoursout=0;
                                              $minutesout=0;
                                              $secondsout =0;
                                              $timeleft="";
                                              if($today_date <= $auction_startdate)
                                              {
                                                  //start - end
                                                  $timeduration =  $auction_enddate - $auction_startdate;
  
                                                  if($timeduration <=0){$timeleft = 0;}
                                                  else{
                                                      $daysout = floor($timeduration / $day);
                                                      $hoursout = floor(($timeduration - $daysout * $day)/$hour);
                                                      $minutesout = floor(($timeduration - $daysout * $day - $hoursout * $hour)/$minute);
                                                      //$secondsout = $timeduration - $daysout * $day - $hoursout * $hour - $minutesout * $minute;
                                                      if($daysout>0){$timeleft=$daysout."d";}
                                                      if($hoursout>0){$timeleft.=" / ".$hoursout."h";}
                                                      if($minutesout>0){$timeleft.=" / ".$minutesout."m";}
                                                  }
                                              }
                                              else if($today_date > $auction_startdate && $today_date < $auction_enddate)
                                              {
                                                  //end - today
                                                  $timeduration =  $auction_enddate - $today_date;
  
                                                  if($timeduration <=0){$timeleft = 0;}
                                                  else{
                                                      $daysout = floor($timeduration / $day);
                                                      $hoursout = floor(($timeduration - $daysout * $day)/$hour);
                                                      $minutesout = floor(($timeduration - $daysout * $day - $hoursout * $hour)/$minute);
                                                      //$secondsout = $timeduration - $daysout * $day - $hoursout * $hour - $minutesout * $minute;
                                                      if($daysout>0){$timeleft=$daysout."d /";}
                                                      if($hoursout>0){$timeleft.=$hoursout."h";}
                                                      if($minutesout>0){$timeleft.=" / ".$minutesout."m";}
                                                  }
                                              }
                                              else {
                                                  //old dated
                                                  $timeleft = 0;
                                                  
                                              }
                                              ///////time left calculation end////////
                                              
                                              ///////day,month,date calculation start////////
                                              $auction_enddate ="";
                                              $auction_enddate = strtotime($actionpro->end_time_of_auction);
                                              $bidclose = "CL:".date("D",$auction_enddate).".,".date("M",$auction_enddate).".".date("d",$auction_enddate);
                                               ///////day,month,date calculation end////////
                                               $isauctiondate_today = false;
                                               if(date("Y/m/d") == date("Y/m/d",strtotime($actionpro->auction_date)))
                                               {
                                                  $isauctiondate_today = true;
                                               }
  
  
                                          ?>
                                     
                                     <input type="hidden" id="id<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->id); ?>">
  
                                      <table id="example2" class="table table-striped table-bordered">
                                          <tbody>
                                              <tr> 
                                                  <td rowspan="7"  style="width: 120px;">
                                                      <div class="info" style="margin-bottom: 115px;">
                                                      <font style="color:#ff8c00">
                                                          <b style="color: #000;"><?php echo e($bidclose); ?></b>
                                                          <?php echo e($isauctiondate_today==true?"New Today!":""); ?>

                                                      </font> <!---CL:Tue.,Sep.28---->
                                                      </div>
                                                      <a class="thumbnail" href="">
                                                          <img src="<?php echo e(url('/')); ?>/<?php echo e($actionpro->thumbnail_sm_image); ?>" id="image<?php echo e($actionpro->id); ?>" width="100" height="75">
                                                      </a>
                                                  </td>
  
                                                  <th style="width:95px" nowrap="nowrap">Auction No.</th>
                                                  <th style="width:85px" nowrap="nowrap">Maker</th>
                                                  <th style="width:55px" nowrap="nowrap">Year</th>
                                                  <th style="width:55px" nowrap="nowrap">Hour</th>
                                                  <th colspan="2" nowrap="nowrap">Delivery Yard</th>
                                                  <th style="width:95px" nowrap="nowrap"><strong>Releasing Charge</strong></th>
                                                  </tr>
                                                  <tr> 
                                                      <td>
                                                          <a href="<?php echo e(route('auction.product_details',[$actionpro->id])); ?>">
                                                              <span id="product_no<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->product_no); ?></span>
                                                          </a>
                                                      </td>
                                                      <td><span id="brand<?php echo e($actionpro->id); ?>"><?php echo e(strtoupper($actionpro->brand->name_en)); ?></span></td>
                                                      <td><span id="modelyear<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->model_year); ?></span></td>
                                                      <td><span id="usedhour<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->used_hour); ?></span></td>
                                                      <td colspan="2"><span id="deliveryplace<?php echo e($actionpro->id); ?>"><?php echo e(ucfirst($actionpro->delivery_place)); ?><br>Arrived (搬入済)</span></td>
                                                      <td><strong><span id="realeasingcharge<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->releasing_charge !=0?"JPY ".number_format($actionpro->releasing_charge):""); ?></span></strong></td>
                                                  </tr>
                                                  <tr> 
                                                      <th colspan="2">Model / Serial</th>
                                                      <th colspan="2" nowrap="nowrap">Current Bid</th>
                                                      <th nowrap="nowrap">Bidder No.</th>
                                                      <th nowrap="nowrap">Bids</th>
                                                      <th nowrap="nowrap">Time Left</th>
                                                  </tr>
                                                  <tr> 
                                                      <td colspan="2"><b><span id="modelno<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->model_no); ?></span> / <span id="serialno<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->serial_no); ?></span></b></td>
                                                      <td colspan="2">
                                                      <strong>JPY 
                                                      
                                                          <span id="auction_max_bidder_price<?php echo e($actionpro->id); ?>"><?php echo e(number_format($actionpro->bid_start_price < $actionpro->auction_max_bid_amount ? $actionpro->auction_max_bid_amount : $actionpro->bid_start_price)); ?></span>
                                                      
                                                      </strong>
                                                      </td>
                                                      <td nowrap="nowrap">
                                                      
                                                      <input type="hidden" id="bidder_id<?php echo e($actionpro->id); ?>">
                                                      
                                                      <span id="biddercountry<?php echo e($actionpro->id); ?>">
                                                           <img class="flag" src="home%20page_files/81.png">
                                                      </span>
                                                      <span id="auction_max_bidder_code<?php echo e($actionpro->id); ?>">1081****</span>
                                             
                                                      </td> 
                                                      <td>
                                                          <span id="totalbids<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->total_bids); ?></span>
                                                      </td>
                                                      <td><span id="timeleft<?php echo e($actionpro->id); ?>"><?php echo e($timeleft); ?></span></td> <!---4d / 01h / 46m--->
                                                  </tr>
                                                  <tr>
                                                      <th style="border-bottom:none">Feature &amp;<br>Comment</th>
                                                      <td colspan="6" style="border-bottom:none">
                                                          <span id="featureandcomment<?php echo e($actionpro->id); ?>"><?php echo e($actionpro->long_description); ?></span>
                                                      </td>
                                                  </tr>
                                                  <tr>
                                                      <th>Bidding Status</th>
  
                                                      <td colspan="5" id="biddingstatusresult<?php echo e($actionpro->id); ?>">
                                                          <font color="#ffff00">
                                                          <b style="display:inline-block;">
                                                              <span id="biddingstatus<?php echo e($actionpro->id); ?>"></span>
                                                          </b>
                                                          </font>
                                                      </td>
                                                      <td>
                                                          <input type="button" class="button reload" onclick="reload(<?php echo e($actionpro->id); ?>);" value="Reload">
                                                      </td>
                                                  </tr>
                                                  <tr>
                                                      <th>Bid</th>
                                                      <td colspan="6">
                                                          <input type="hidden"  id="biddecreaseprice<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->bid_increase_decrease_price); ?>">
                                                          <input type="hidden"  id="bidincreaseprice<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->bid_increase_decrease_price); ?>">
                                                          <input type="hidden"  id="bidcurrentprice<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->bid_start_price < $actionpro->auction_max_bid_amount ? $actionpro->auction_max_bid_amount : $actionpro->bid_start_price); ?>">
                                                          <input type="hidden"  id="bidingstartprice<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->bid_start_price); ?>">
                                                          <input type="hidden"  id="bidtotalprice<?php echo e($actionpro->id); ?>" value="<?php echo e($actionpro->bid_start_price < $actionpro->auction_max_bid_amount ? $actionpro->auction_max_bid_amount : $actionpro->bid_start_price); ?>">
  
  
                                                          <input type="button" id="<?php echo e($actionpro->id); ?>"  value="-<?php echo e(number_format($actionpro->bid_increase_decrease_price)); ?>" onclick="biddecreasepriceset(this.id)"   style="width: 80px;height:35px;border-radius:3px;">
                                                          <input type="text"   id="bidprice<?php echo e($actionpro->id); ?>"  value="<?php echo e(number_format($actionpro->bid_start_price < $actionpro->auction_max_bid_amount ? $actionpro->auction_max_bid_amount : $actionpro->bid_start_price)); ?>" style="height:35px;width: 120px;"  readonly="readonly">
                                                          <input type="button" id="<?php echo e($actionpro->id); ?>"  value="+<?php echo e(number_format($actionpro->bid_increase_decrease_price)); ?>" onclick="bidincreasepriceset(this.id)"  style="width: 80px;height:35px;border-radius:3px;">
                                                          
                                                          <input type="button" id="bidbtn<?php echo e($actionpro->id); ?>" onclick="bidSubmit(447645);return false;" value="Bid" class="button bid">
  
                                                      </td>
                                                  </tr>
                                                  
                                          </tbody>
                                          
                                      <div class="tablegap"></div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                          <p style="font-size: 16px;font-weight: bold;">Sorry!!! No Data Found</p>
                                      <?php endif; ?>
                                  </table>
                                  </td> 
                              </tr>
                          </tbody>
                          
                      </table>
                      
                      <?php echo e($auctionproducts->links()); ?>

                      
  
                  </div>    
              </div>
          </div>    
         </div>
      
      </div>
      </section>
      
      
      </section>
  </div>
    
    
  </div>
</section>





  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/en/welcome.blade.php ENDPATH**/ ?>