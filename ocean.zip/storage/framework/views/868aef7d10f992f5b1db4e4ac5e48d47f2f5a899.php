

<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 

<!--=============================  ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
    
    <style>
      .header_title{font-size: 18px !important;}
      
    .msgstyle{padding: 15px;text-align: center;}
    .backlink{color: #fbb206;font-weight: bold;font-size: 18px;}
  </style>    
  
  <div class="cat-items-grid">
  <section id="home" class="home-page-content page-content">

      
      
      
      <section class="products-section">
      <div class="container">
        <div class="row">  


        




        <div id="main_contents">
         
            <div class="msgstyle">
                <?php if(isset($msg)): ?>
                <h4 style="border: 1px solid #fbb206;padding:20px;"> <?php echo e($msg); ?></h4>
                <?php endif; ?>
                <?php if(isset($emsg)): ?>
                <h4 style="border: 1px solid #fbb206;padding:20px;color:rgb(252, 2, 2)"> <?php echo e($emsg); ?></h4>
                <?php endif; ?>

                <br><br><br>
                <a href="<?php echo e(route('woody.auction')); ?>" class="backlink"><img src="<?php echo e(url('fontend/images/left-arrow.png')); ?>" style="width:50px;">Back To Woody Auction</a>  
            </div>  
            
         
        </div>
       </div>
      
      </div>
      </section>
      
      
      </section>
  </div>
    
    
  </div>
</section>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/fontend/en/passwordretrieve_message.blade.php ENDPATH**/ ?>