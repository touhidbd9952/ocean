<?php $__env->startSection('content'); ?>

 <!-- Swiper -->
 <!-- Breadcrumbs-->
<style>
@media(min-width:768px)
{
  .container{width: 950px !important;}
}
.yellow {background: #F5A641;}
.red{background:#e94335;}
.green{background:#34a853;}
.blue{background:#4285f4;}
.yellow a,.red a,.green a,.blue a{font-size:20px;font-weight:bold;color:#fff;display:block;}
.yellow a span,.red a span,.green a span,.blue a span
{
    clear: left;
    margin-top: 0px;
    display: block;
}
.yellow a i,.red a i,.green a i,.blue a i
{
    font-size: 20px;
}
.yellow-color a, .yellow-color a i{color:#F5A641;}
.red-color a, .red-color a i{color:#e94335;}
.blue-color a, .blue-color a i{color:#4285f4;}
#div_yellow {border-left: 8px dotted #F5A641;}
#div_red {border-left: 8px dotted #e94335;}
#div_green {border-left: 8px dotted #34a853;}
#div_blue {border-left: 8px dotted #4285f4;}
.list-group {margin-left: 10px;}
.list-group-item {border: 1px solid #fff;}
.textmessage{border: 1px solid #f9a404;border-radius: 50px;font-size: 16px;font-weight: bold;color: #f9a404;}
</style>    
<!--=============================  ======================================-->


  <?php echo "Home Page";?>



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitco\resources\views/fontend/en/welcome.blade.php ENDPATH**/ ?>