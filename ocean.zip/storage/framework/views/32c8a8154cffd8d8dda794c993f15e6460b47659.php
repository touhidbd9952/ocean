<?php $__env->startSection('content'); ?>

<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <?php 
            $loginuser = Illuminate\Support\Facades\Auth::user()->name;
            ?>

            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Dashboard &nbsp;: &nbsp;<?php echo e($loginuser); ?></h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->


<div class="container-fluid">
    <div class="row">
        

        <?php 
        $categories = App\Models\Category::latest()->take(10)->get();  
        $products = App\Models\Product::latest()->with('category')->take(10)->get();  
        ?>

        <!----======= last 10  Categories  ==========---->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header border-0">
                  <h3 class="card-title">Categories <span style="float: right;font-size:10px;">last 10</span></h3>
                  
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle">
                    <thead>
                    <tr>
                      <th>Image</th>
                      <th>Title</th>
                      <th>Status</th>
                      <th>created_at</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                    <tr>
                      <td>
                        <img src="<?php echo e(asset($c->image)); ?>" alt="Product 1" class="img-circle img-size-32 mr-2" style="height: 50px; width:auto;">
                      </td>
                      <td><?php echo e($c->title); ?></td>
                      <td>
                        <?php echo e($c->publish_status); ?>

                      </td>
                      <td>
                        <?php echo e($c->created_at); ?>

                      </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                  </table>
                </div>
              </div>

        </div>

        <!----======= last 10  Products  ==========---->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header border-0">
                  <h3 class="card-title">Products <span style="float: right;font-size:10px;">last 10</span></h3>
                  
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle">
                    <thead>
                    <tr>
                      <th>Category</th>
                      <th>Title</th>
                      <th>Status</th>
                      <th>created_at</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                    <tr>
                      <td>
                        <img src="<?php echo e(asset($p->thumbnail_image)); ?>" alt="Product 1" class="img-circle img-size-32 mr-2" style="height: 50px; width:auto;">
                        <?php echo e($p->category->title); ?>

                      </td>
                      <td><?php echo e($p->title); ?></td>
                      <td>
                        <?php echo e($p->publish_status); ?>

                      </td>
                      <td>
                        <?php echo e($p->created_at); ?>

                      </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                  </table>
                </div>
              </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woody\resources\views/admin/home.blade.php ENDPATH**/ ?>