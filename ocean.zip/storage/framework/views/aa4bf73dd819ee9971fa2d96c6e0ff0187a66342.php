<html>
  <head>

    <meta http-equiv="content-type" content="text/html; ">
  </head>
  <body>
    <br>
      <br>
      <br>
      Woodyオークションに参加いただきありがとうございます。
      <br>
      <br>

      パスワードを取得するには、以下のリンクをクリックしてください
      <br>
      <br>
      <a href="<?php echo e($data['url']); ?>">Click here to change your auction password</a>
      <br>
      <br>
      ご不明な点は下記にお問い合わせください。<br>
      <br>
      =====================================================<br>
      株式会社　Woody<br>
      電話番号: +81(0)4-7637-6694<br>
      FAX番号 : +81(0)4-7637-6695<br>
      URL : <a class="moz-txt-link-freetext" href="https://auction.woodyengineering.com/">https://auction.woodyengineering.com/</a><br>
      E-Mail: <a class="moz-txt-link-abbreviated" href="mailto:info@woodyengineering.com">info@woodyengineering.com</a><br>
      =====================================================<br>
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/mail/forgetpassMail.blade.php ENDPATH**/ ?>