<div class="lan" style="position: absolute;top:-30px;right:0px;">
    <ul>
      <li id="jp"><a href="javascript:" onclick="change_language('jp')">Japanese</a></li>
      <li id="en"><a href="javascript:" onclick="change_language('en')">English</a></li>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\freeman\resources\views/inc/fontend_master_language.blade.php ENDPATH**/ ?>