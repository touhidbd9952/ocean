

<?php $__env->startSection('content'); ?>

 <!-- Swiper -->
 <!-- Breadcrumbs-->
<style>
.header {
  text-align: center;
  background-color: #f5a63f;
  width: 100%;
  margin: 0px auto;
    margin-bottom: 0px;
  margin-bottom: 40px;
  z-index: 999;
  padding: 40px 20px 20px;
  color: #ffffff;
}
.container-fluid {
  width: 100%;
  margin: 0px;
  padding: 0px;
}
.box {
  background-color: rgba(0,0,0,0);
  margin: 2px;
  padding: 0px 0;
}
i {
  color: #fff;
  font-size: 36px;
  padding-right: 10px;
}
h1 {
  font-family: 'Roboto';
  font-size: 36px;
  font-style: normal;
  font-weight: 100;
  text-transform: uppercase;
}
h2 {
  margin-top: 0px;
  color: #333333;
  display: block;
  font-size: 15px;
  font-weight: 400;
  text-align: center;
  text-transform: uppercase;
  padding: 10px 0;
}
h5 {
  color: #e74c3c;
  text-transform: uppercase;
}
h4 {
  font-size: 25px;
  font-weight: 100;
  padding: 20px;
  text-align: center;
  color: #333333;
  text-transform: uppercase;
  border-bottom: 1px dotted rgba(0,0,0,.2);
  border-top: 1px dotted rgba(0,0,0,.2);
}
.text_l{text-align: right;}

</style>    
<!--=============================  ======================================-->


<div class="header">
	<div class="container">
    	 <div class="row">
        	<div class="col-md-12">
            	<h1 style="color: #fff">job Provider Registration</h1>
              <div class="lan" style="position: absolute;top:-30px;right:0px;">
                <ul>
                  <li id="jp"><a href="javascript:" onclick="change_language('jp')">Japanese</a></li>
                  <li id="en"><a href="javascript:" onclick="change_language('en')">English</a></li>
                </ul>
              </div>
              <br>
            </div>			
        </div>
    </div>
</div>


<div class="container-fluid" style="margin-bottom: 50px;">
	<div style="max-width: 600px;text-align:center;margin:0 auto;">
    To Create A Job Provider Account, Please Fill-Up Below Registration Form 
    <br><br>
  </div>
		<div style="padding: 0; margin: 0;" class="row">		
		
			<div style="padding: 0; margin: 0;" class="col-md-12">				
			
        <!--------------------==================== JOB PROVIDER ===========================---------------------------->
        <div class="col-md-3">&nbsp;</div>
				<div class="col-md-6">
                    <div class="box row">
                      <div class="col-md-2">&nbsp;</div>
                      <div class="col-md-10" style="text-align: center;">
                        
                          <form method="POST" action="https://woodyengineering.com/woodyltd/login">

                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                              <label for="image"
                                  class="col-sm-3 text-end control-label col-form-label text_l">&nbsp;</label>
                              <div class="col-sm-9">
                                  <img src="<?php echo e(asset('fontend')); ?>/images/man.png" id="output" style="width: 150px;height:175px;float: right;border: 1px solid #ccc;">
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="image"
                                  class="col-sm-3 text-end control-label col-form-label text_l">私の写真</label>
                              <div class="col-sm-9">
                                  <input type="file"  name="image" onchange="showimage()" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Select Your Photo">
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="fname"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Full Name</label>
                              <div class="col-sm-9">
                                  <input type="text"  name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Full Name Here">
                                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="postcode"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Post Code</label>
                              <div class="col-sm-9">
                                  <input type="text"  name="postcode" class="form-control <?php $__errorArgs = ['postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="post code Here">
                                  <?php $__errorArgs = ['postcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="address"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Address</label>
                              <div class="col-sm-9">
                                  <textarea  name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="email"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Email</label>
                              <div class="col-sm-9">
                                  <input type="email"  name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Email Here">
                                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
    
                            <div class="form-group row">
                              <label for="password"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Password</label>
                              <div class="col-sm-9">
                                  <input type="password"  name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Password Here">
                                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="phone"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Phone</label>
                              <div class="col-sm-9">
                                  <input type="text"  name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Phone Here">
                                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>

                            <div class="form-group row">
                              <label for="fax"
                                  class="col-sm-3 text-end control-label col-form-label text_l">Fax</label>
                              <div class="col-sm-9">
                                  <input type="text"  name="fax" class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Fax Here">
                                  <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
    
                            
    
                            <div class="form-group row mb-0" style="padding-bottom: 25px;">
                                <label class="col-md-3 col-form-label text-md-right"></label>
                                <div class="col-md-8">
                                    <button type="submit" class="btn btn-primary" style="width: 251px;float: left;">
                                        Save
                                    </button>
                                </div>
                            </div>
                            
                        </form>

                        
                        
                      </div>
                  </div>
				
				</div>


        
				
				<div class="clearfix"></div>
		
			</div>		
			
		</div>
			
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
  function showimage()
  {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  }
</script>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freeman\resources\views/fontend/jp/job_provider_reg.blade.php ENDPATH**/ ?>