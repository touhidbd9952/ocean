<?php $__env->startSection('content'); ?>

<style>
  .page{background: #fbfafa;}
  
  @font-face {
    font-family: 'password';
    font-style: normal;
    font-weight: 400;
    src: url(https://jsbin-user-assets.s3.amazonaws.com/rafaelcastrocouto/password.ttf);
  }
  input.myclass{font-family: 'password';width: 250px;border: 1px solid #ccc;}
  </style>
<!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <?php 
            $loginuser = Illuminate\Support\Facades\Auth::user()->name;  
            ?>

            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Dashboard &nbsp;: &nbsp;<?php echo e($loginuser); ?></h4>
                        <div class="ms-auto text-end">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->


<div class="container-fluid">
    <div class="row">
      <div class="col-md-6"></div>
       <div class="col-md-6" style="height: 30px;margin-bottom:20px;">
        <form action="<?php echo e(route('admin.tokenno')); ?>" method="post" >
                       
          <?php echo csrf_field(); ?>

          <div class="form-group row">
              <label for="fname"
                  class="col-sm-3 text-end control-label col-form-label" >User Token No</label>
              <div class="col-sm-9">
                  <input id="password" type="search"  name="password_token"  autocomplete="off" class="form-control myclass <?php $__errorArgs = ['password_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required style="width: 200px;float: left;">
                  <?php $__errorArgs = ['password_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger"> <?php echo e($message); ?>  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              
                  <button type="submit" class="btn btn-primary" style="float:left;margin-left:5px;">
                      Add
                  </button>
              </div>
          </div>
      </form> 
       </div>
    </div> 

    <div class="row">
        

        <?php 
        $worktypes = App\Models\Worktype::latest()->take(10)->get();  
        $works = App\Models\Work::latest()->with('worktype')->take(10)->get();  
        ?>

        <!----======= last 10  Categories  ==========---->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header border-0">
                  <h3 class="card-title">Worktypes <span style="float: right;font-size:10px;">last 10</span></h3>
                  
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle">
                    <thead>
                    <tr>
                      <th>Title</th>
                      <th>Created_at</th>
                      <th>Updated_at</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $worktypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                    <tr>
                      <td><?php echo e($c->title); ?></td>
                      <td>
                        <?php echo e($c->created_at); ?>

                      </td>
                      <td>
                        <?php echo e($c->updated_at); ?>

                      </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                  </table>
                </div>
              </div>

        </div>

        <!----======= last 10  Products  ==========---->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header border-0">
                  <h3 class="card-title">Works <span style="float: right;font-size:10px;">last 10</span></h3>
                  
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-striped table-valign-middle">
                    <thead>
                    <tr>
                      <th>Work_type</th>
                      <th>Work_title</th>
                      <th>Charge (per hour)</th>
                      
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    if($p->work_type_id == 2)
                    {
                    ?>  
                    <tr>
                      <td>
                        <?php echo e($p->worktype->title); ?>

                      </td>
                      <td><?php echo e($p->work_title); ?></td>
                      <td>
                        <?php echo e($p->charge); ?>&nbsp;¥
                      </td>
                    </tr>
                    <?php 
                    }
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    if($p->work_type_id == 1)
                    {
                    ?>  
                    <tr>
                      <td>
                        <?php echo e($p->worktype->title); ?>

                      </td>
                      <td><?php echo e($p->work_title); ?></td>
                      <td>
                        <?php echo e($p->charge); ?>&nbsp;¥
                      </td>
                    </tr>
                    <?php 
                    }
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                  </table>
                </div>
              </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freeman\resources\views/backend/admin/home.blade.php ENDPATH**/ ?>