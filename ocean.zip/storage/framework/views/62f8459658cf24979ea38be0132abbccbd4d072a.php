<span>
<?php 

    $LG_Login_ID ="Login ID";
    $LG_Password ="Password";
    $LG_Login ="Login";
    $LG_Forgot_Your_Password ="Forgot Your Password";

    $LG_Auction_No ="Auction No"; 	
    $LG_Maker ="Maker"; 	
    $LG_Year ="Year"; 	
    $LG_Hour ="Hour"; 	
    $LG_Delivery_Yard ="Delivery Yard"; 	
    $LG_Releasing_Charge ="Releasing Charge";
    $LG_Model ="Model"; 
    $LG_Serial ="Serial"; 	
    $LG_Current_Bid ="Current Bid";	
    $LG_Bidder_No ="Bidder No";	
    $LG_Bids ="Bids";	
    $LG_Time_Left="Time Left";
    $LG_Feature_Comment = "Feature Comment";

    $LG_Category_List = "Category List";
    $LG_Item_Search = "Item Search";
    $LG_Search = "Search";
    $LG_Choice = "Choice";
    $LG_ALL = "ALL";
    $LG_New_Today = "New Today";
    $LG_End_soon = "End soon";

    $LG_Reload = "Reload";

    if(session()->get('language')=='jp')
    {
        $LG_Login_ID ="ログインID";
        $LG_Password ="パスワード";
        $LG_Login ="ログイン";
        $LG_Forgot_Your_Password ="パスワードをお忘れですか";

        $LG_Auction_No ="オークション番号"; 	
        $LG_Maker ="メーカー"; 	
        $LG_Year ="年"; 	
        $LG_Hour ="時間"; 	
        $LG_Delivery_Yard ="配達ヤード"; 	
        $LG_Releasing_Charge ="料金の解放";
        $LG_Model ="モデル"; 
        $LG_Serial ="シリアル"; 	
        $LG_Current_Bid ="現在の入札";	
        $LG_Bidder_No ="入札者番号";	
        $LG_Bids ="入札";	
        $LG_Time_Left="残り時間 ";
        $LG_Feature_Comment = "機能コメント";

        $LG_Category_List = "カテゴリリスト";
        $LG_Item_Search = "アイテム検索";
        $LG_Search = "検索";
        $LG_Choice = "選択";
        $LG_ALL = "全て";
        $LG_New_Today = "今日の新機能";
        $LG_End_soon = "もうすぐ終了";

        $LG_Reload = "リロード";
    }


?>
</span><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/inc/page_language.blade.php ENDPATH**/ ?>