

<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 

<!--=============================  ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
    
    <style>
      .header_title{font-size: 18px !important;}
      
    .msgstyle{padding: 15px;border: 1px solid #fbbd05;text-align: center;}
    .backlink{color: #fbb206;font-weight: bold;font-size: 18px;}
    .panel-primary {border-color: #F5A85F;}
    .redcolor{background: #FF0000;color: #FFFFFF;border: solid 1px #FF0000;border-radius: 10px;padding: 0.0em 0.5em;font-weight: bold;}
  </style>    
  
  <div class="cat-items-grid">
  <section id="home" class="home-page-content page-content">

      
    <?php 
    $auction_date =  date('Y-m-d',strtotime(App\Models\Product::max('auction_date')));  
    $auction_dates = App\Models\Product::distinct('auction_date')->where('auction_date','not like', '%'.$auction_date.'%')->orderby('auction_date','desc')->get();  //dd($auction_dates);
    ?>
    
      
      <section class="products-section">
      <div class="container">
        <div class="row">  


        <div class="col-md-12">
            <a href="<?php echo e(route('woody.search_site_logout')); ?>" class="btn btn-primary" style="float: right;display:inline-block;margin-top:-50px;">Logout</a>
            <a href="javascript:" onclick="history.back(); return false;" class="btn" style="float:right;display:inline-block;margin-top:-50px;margin-right:100px;border: 1px solid #F5A63F;color: #F5A63F;">
                <img src="<?php echo e(url('fontend/images/left-arrow.png')); ?>" style="height: 20px;">Back
            </a>
         
            <h4>Results of <?php echo e(date('Y-m-d',strtotime($auctiondate))); ?></h4>
            [SOLD]<br>
            <table  class="table table-striped table-bordered">
                <thead  class="thead-dark">
                    <tr class="table-secondary">
                        <th class="headercolor">AUCTION No.</th>
                        <th class="headercolor">Model</th>
                        <th class="headercolor">Serial No.</th>
                        <th class="headercolor">Delivery Place</th>
                        <th class="headercolor">Price</th>
                    </tr>
                </thead>
             <tbody>
            <?php $__currentLoopData = $auction_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
              <?php 
              if($acs->final_result == 'sold')
              {
              ?>
             <tr>
              <td><?php echo e($acs->product_no); ?></td>
              <td><?php echo e($acs->model_no); ?></td>
              <td><?php echo e($acs->serial_no); ?></td>
              <td><?php echo e($acs->delivery_place); ?></td>
              <td><?php echo e($acs->auction_max_bid_amount); ?></td>
             </tr>
             <?php 
              }
             ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
            </table>

            <br><br>

            

            
            
         
        </div>
        

        

       </div>
      
      </div>
      </section>
      
      
      </section>
  </div>
    
    
  </div>
</section>


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/fontend/en/search_site_auction_result.blade.php ENDPATH**/ ?>