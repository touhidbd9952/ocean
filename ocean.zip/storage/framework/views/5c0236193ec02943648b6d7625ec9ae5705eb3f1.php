

<?php $__env->startSection('content'); ?>
 
 
 <!-- Swiper -->
 <!-- Breadcrumbs-->
 

<!--=============================  ======================================-->
<section class="section section-md bg-white">
  <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
    
    <style>
      .headercolor{
    background: #FBE8D0;
    color: #776161;
    border-color: #FBE8D0;
}
    
      @media(max-width:767px)
      {
          .pmr{padding-right: 15px;}
      }
  </style>    
  
  <div class="cat-items-grid">
  <section id="home" class="home-page-content page-content">
      <section class="products-section">
      <div class="container">
        <div class="row">  





        <div>
         <div style="min-height:100px;border:1px solid #ccc;padding:10px;">  
            
            <div id="contents-wrapper">
                <?php 
                //echo $auction_date;exit;
                ?>
                <h4>Black-Listed Member</h4>
                <br>
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <thead  class="thead-dark">
                            <tr class="table-secondary">
                                <th class="headercolor" style="width:30%">Name</th>
                                <th class="headercolor" style="width:30%">Email</th>
                                <th class="headercolor" style="width:20%">Company</th>
                                <th class="headercolor" style="width:20%">Country</th>
                            </tr>
                        </thead>
                    </thead>

                 <tbody>
                    <?php $__currentLoopData = $bidderdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                   <tr>
                    <td><?php echo e($acs->name); ?></td>
                    <td><?php echo e($acs->email1); ?></td>
                    <td><?php echo e($acs->company_name); ?></td>
                    <td><?php echo e($acs->country); ?></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
                
            </div>
     
         </div>
        </div>
       </div>
      
      </div>
      </section>
      
      
      </section>
  </div>
    
    
  </div>
</section>





  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\woodyauction\resources\views/fontend/en/bidderblacklisted.blade.php ENDPATH**/ ?>