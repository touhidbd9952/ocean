<div class="container-fluid" style="background:#FBFBFB;height:100px;width:100%;float:left;">
    <div id="share-links" style="margin:0 auto;"> 
    
        <div id="share-links-Div1">
          <i class="fa fa-envelope" aria-hidden="true"></i>
          <ul>
              <li><a href="">Home</a></li><br>
              <li><a href="https://localhost/ocean/aboutus">AboutUS</a></li><br>
          </ul>
      </div>
      <!----------------------->
      <div id="share-links-Div2">
          <img src="{{ asset('fontend') }}/images/Car-14.png" height="53">
          <ul>
               <li><a href="https://localhost/ocean/vehicles">Vehicles</a></li><br>
              <li><a href="https://localhost/ocean/contact">ContactUS</a></li><br>
          </ul>
      </div>
        <br class="clear">
    </div>
    </div>
      <!------------------------->
    <footer>
          copyright info © Ocean.com.bd, webmaster © Ocean.com.bd. All right reserved
    </footer>